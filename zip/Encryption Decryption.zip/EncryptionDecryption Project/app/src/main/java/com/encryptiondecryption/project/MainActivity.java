package com.encryptiondecryption.project;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import com.encryptiondecryption.project.SplashIntro.StepperWizardColor;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    String encryptedAlgorithm, decryptedAlgorithm, encryptedString;
    Button btn_encryption, btn_decryption, btn_send, btn_decryption_message;
    Spinner encryption_spinner, decryption_spinner;
    ImageView imgpickcontact;
    TextInputEditText edt_mobile, edt_message, edt_decyption_message, edt_key, edt_decryption_key;
    TextView final_decrypted_text, tvclear,tvhelp;
    public static final int RequestPermissionCode = 1;
    Intent intent;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static final int REQUEST = 112;
    LinearLayout decryptionLayout, encryptionLayout;

    String[] Options = {"Sim 1", "Sim 2"};
    AlertDialog.Builder window;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);


        decryptionLayout = findViewById(R.id.decryptionLayout);
        encryptionLayout = findViewById(R.id.encryptionLayout);
        btn_send = findViewById(R.id.btn_send);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_message = findViewById(R.id.edt_message);
        edt_key = findViewById(R.id.edt_key);
        edt_decyption_message = findViewById(R.id.edt_decyption_message);
        edt_decryption_key = findViewById(R.id.edt_decryption_key);
        edt_decyption_message = findViewById(R.id.edt_decyption_message);
        final_decrypted_text = findViewById(R.id.final_decrypted_text);
        btn_encryption = findViewById(R.id.btn_encryption);
        btn_decryption = findViewById(R.id.btn_decryption);
        tvclear = findViewById(R.id.tvclear);
        btn_decryption_message = findViewById(R.id.btn_decryption_message);
        encryption_spinner = (Spinner) findViewById(R.id.encryption_spinner);
        decryption_spinner = (Spinner) findViewById(R.id.decryption_spinner);
        tvclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MainActivity.class));
            }
        });
        tvhelp = findViewById(R.id.tvhelp);
        tvhelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, StepperWizardColor.class));
            }
        });


        window = new AlertDialog.Builder(this);
        window.setTitle("Select Sim");

        List<String> weightList = new ArrayList<String>();
        weightList.add("Select Algorithm");
        weightList.add("Caesar Cipher Algorithm");
        weightList.add("Rail Fence Cipher Algorithm");
        weightList.add("PlayFair Cipher Algorithm");
        weightList.add("Vigenere Cipher Algorithm");

        ArrayAdapter<String> adapterWeight = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, weightList);
        adapterWeight.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        encryption_spinner.setAdapter(adapterWeight);
        decryption_spinner.setAdapter(adapterWeight);


        encryption_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                String items = encryption_spinner.getSelectedItem().toString();
                Log.i("Selected item : ", items);
                if (encryption_spinner.getSelectedItem().toString().equals("Caesar Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

                } else if (encryption_spinner.getSelectedItem().toString().equals("Rail Fence Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

                } else if (encryption_spinner.getSelectedItem().toString().equals("PlayFair Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT);

                } else if (encryption_spinner.getSelectedItem().toString().equals("Vigenere Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        decryption_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                String items = decryption_spinner.getSelectedItem().toString();
                Log.i("Selected item : ", items);
                if (decryption_spinner.getSelectedItem().toString().equals("Caesar Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

                } else if (decryption_spinner.getSelectedItem().toString().equals("Rail Fence Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);

                } else if (decryption_spinner.getSelectedItem().toString().equals("PlayFair Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT);

                } else if (decryption_spinner.getSelectedItem().toString().equals("Vigenere Cipher Algorithm")) {
                    edt_key.setText("");
                    edt_key.setInputType(InputType.TYPE_CLASS_TEXT);
                    edt_decryption_key.setText("");
                    edt_decryption_key.setInputType(InputType.TYPE_CLASS_TEXT);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        imgpickcontact = findViewById(R.id.imgpickcontact);
        imgpickcontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EnableRuntimePermission();
            }
        });
        decryptionLayout.setVisibility(View.GONE);
        encryptionLayout.setVisibility(View.VISIBLE);
        btn_encryption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                encryptionLayout.setVisibility(View.VISIBLE);
                decryptionLayout.setVisibility(View.GONE);
                btn_encryption.setTextColor(Color.parseColor("#ffffff"));
                btn_decryption.setTextColor(Color.parseColor("#B1B0B0"));
            }
        });

        btn_decryption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decryptionLayout.setVisibility(View.VISIBLE);
                encryptionLayout.setVisibility(View.GONE);
                btn_decryption.setTextColor(Color.parseColor("#ffffff"));
                btn_encryption.setTextColor(Color.parseColor("#B1B0B0"));
            }
        });

        final String SENT = "SMS_SENT", DELIVERED = "SMS_DELIVERED";
        final PendingIntent sentPI = PendingIntent.getBroadcast(this, 0, new Intent(
                SENT), 0);
        final PendingIntent deliveredPI = PendingIntent.getBroadcast(this, 0,
                new Intent(DELIVERED), 0);

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                encryptedAlgorithm = encryption_spinner.getSelectedItem().toString();

                if (edt_mobile.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Mobile Number", Toast.LENGTH_SHORT).show();
                } else if (edt_message.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Message", Toast.LENGTH_SHORT).show();
                } else if (encryptedAlgorithm.equals("Select Algorithm")) {
                    Toast.makeText(MainActivity.this, "Please Select Algorithm", Toast.LENGTH_SHORT).show();
                } else if (edt_key.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Key", Toast.LENGTH_SHORT).show();
                } else {

                    int permissionCheck = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS);

                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {

                        try {
                            if (Build.VERSION.SDK_INT >= 23) {
                                String[] PERMISSIONS = {android.Manifest.permission.READ_PHONE_STATE};
                                if (!hasPermissions(getApplicationContext(), PERMISSIONS)) {
                                    ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, REQUEST);

                                } else {
                                    //Do here

                                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                    builder.setTitle("Select Sim");
                                    builder.setMessage("Do you want to send SMS ?")
                                            .setCancelable(false)
                                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                                                public void onClick(DialogInterface dialog, int id) {
                                                    try {

                                                        if (encryptedAlgorithm.equals("Caesar Cipher Algorithm")) {
                                                            int dKey = Integer.parseInt(edt_key.getText().toString());
                                                            while (dKey > 26) {
                                                                dKey = dKey / 26;
                                                            }
                                                            edt_decryption_key.setText(dKey + "");
                                                            Log.d("encryptKey", dKey + "");
                                                            encryptedString = caesarCipherEncryption(dKey, edt_message.getText().toString());
                                                        } else if (encryptedAlgorithm.equals("Rail Fence Cipher Algorithm")) {
                                                            encryptedString = railFenceEncryption(Integer.parseInt(edt_key.getText().toString()), edt_message.getText().toString());
                                                        } else if (encryptedAlgorithm.equals("PlayFair Cipher Algorithm")) {
                                                            encryptedString = playFairCypherEncryption(edt_key.getText().toString(), edt_message.getText().toString());
                                                        } else if (encryptedAlgorithm.equals("Vigenere Cipher Algorithm")) {
                                                            encryptedString = vigenereCypherEncryption(edt_key.getText().toString(), edt_message.getText().toString());
                                                        }
                                                        window.setItems(Options, new DialogInterface.OnClickListener() {
                                                            @RequiresApi(api = Build.VERSION_CODES.M)
                                                            @Override
                                                            public void onClick(DialogInterface dialog, int which) {

                                                                Log.d("data:"+edt_mobile.getText().toString()," "+encryptedString);
                                                                if (which == 0) {
                                                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                                                                        {
                                                                            final PendingIntent localPendingIntent1 = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(SENT), 0);
                                                                            final PendingIntent localPendingIntent2 = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(DELIVERED), 0);

                                                                            if (Build.VERSION.SDK_INT >= 22) {
                                                                                SubscriptionManager subscriptionManager = getSystemService(SubscriptionManager.class);

                                                                                @SuppressLint("MissingPermission") SubscriptionInfo subscriptionInfo = subscriptionManager.getActiveSubscriptionInfoForSimSlotIndex(0);
                                                                                if (subscriptionInfo != null || subscriptionInfo != null) {
                                                                                    try {
                                                                                        SmsManager.getSmsManagerForSubscriptionId(subscriptionInfo.getSubscriptionId()).sendTextMessage(edt_mobile.getText().toString(), null, encryptedAlgorithm+"\n"+encryptedString, localPendingIntent1, localPendingIntent2);

                                                                                    }
                                                                                    catch (Exception e){
                                                                                        Toast.makeText(MainActivity.this, e.toString()+"", Toast.LENGTH_SHORT).show();
                                                                                    }
                                                                                } else {
                                                                                    Toast.makeText(MainActivity.this, "Sim 1 not available", Toast.LENGTH_SHORT).show();
                                                                                }
                                                                            }
                                                                            try {
                                                                                SmsManager.getSmsManagerForSubscriptionId(0).sendTextMessage(edt_mobile.getText().toString(), null, encryptedString, localPendingIntent1, localPendingIntent2);

                                                                            }
                                                                            catch (Exception e){
                                                                                Toast.makeText(MainActivity.this, e.toString()+"", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        }
                                                                        Toast.makeText(getApplicationContext(), "SMS Sent", Toast.LENGTH_LONG).show();

                                                                        int secondsDelayed = 1;
                                                                        new Handler().postDelayed(new Runnable() {
                                                                            public void run() {
                                                                                Intent intent1 = new Intent(MainActivity.this, MainActivity.class);
//                                                                                startActivity(intent1);
                                                                            }
                                                                        }, secondsDelayed * 800);
                                                                    } else {
                                                                        SmsManager.getDefault().sendTextMessage(edt_mobile.getText().toString(), null, encryptedString, sentPI, deliveredPI);

                                                                        int secondsDelayed = 1;
                                                                        new Handler().postDelayed(new Runnable() {
                                                                            public void run() {
                                                                                Intent intent1 = new Intent(MainActivity.this, MainActivity.class);
//                                                                                startActivity(intent1);
                                                                            }
                                                                        }, secondsDelayed * 800);
                                                                    }
                                                                } else if (which == 1) {
                                                                    final PendingIntent localPendingIntent1 = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(SENT), 0);
                                                                    final PendingIntent localPendingIntent2 = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(DELIVERED), 0);

                                                                    if (Build.VERSION.SDK_INT >= 22) {
                                                                        SubscriptionManager subscriptionManager = getSystemService(SubscriptionManager.class);

                                                                        @SuppressLint("MissingPermission") SubscriptionInfo subscriptionInfo = subscriptionManager.getActiveSubscriptionInfoForSimSlotIndex(1);
                                                                        if (subscriptionInfo != null || subscriptionInfo != null) {
                                                                            SmsManager.getSmsManagerForSubscriptionId(subscriptionInfo.getSubscriptionId()).sendTextMessage(edt_mobile.getText().toString(), null, encryptedString, localPendingIntent1, localPendingIntent2);
                                                                        } else {
                                                                            Toast.makeText(MainActivity.this, "Sim 2 not available", Toast.LENGTH_SHORT).show();
                                                                        }
                                                                    }
                                                                    SmsManager.getSmsManagerForSubscriptionId(0).sendTextMessage(edt_mobile.getText().toString(), null, encryptedString, localPendingIntent1, localPendingIntent2);

                                                                    Toast.makeText(getApplicationContext(), "SMS Sent", Toast.LENGTH_LONG).show();
                                                                    int secondsDelayed = 1;
                                                                    new Handler().postDelayed(new Runnable() {
                                                                        public void run() {
                                                                            Intent intent1 = new Intent(MainActivity.this, MainActivity.class);
                                                                            startActivity(intent1);
                                                                        }
                                                                    }, secondsDelayed * 800);

                                                                } else {
                                                                    //theres an error in what was selected
                                                                    Toast.makeText(getApplicationContext(), "Hmmm I messed up. I detected that you clicked on : " + which + "?", Toast.LENGTH_LONG).show();

                                                                }
                                                            }
                                                        });
                                                        window.show();

                                                    } catch (
                                                            Exception e) {
                                                        Toast.makeText(MainActivity.this, e.toString() + "", Toast.LENGTH_LONG).show();
                                                    }
                                                }
                                            })
                                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                }
                                            });

                                    AlertDialog alert = builder.create();
                                    alert.show();
                                }

                            } else {
                                //Do here
                            }
                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(),
                                    "SMS failed, please try again.",
                                    Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    } else {
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS},
                                MY_PERMISSIONS_REQUEST_SEND_SMS);
                    }
                }
            }
        });

        btn_decryption_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                decryptedAlgorithm = decryption_spinner.getSelectedItem().toString();
                if (edt_decyption_message.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Message", Toast.LENGTH_SHORT).show();
                } else if (decryptedAlgorithm.equals("Select Algorithm")) {
                    Toast.makeText(MainActivity.this, "Please Select Algorithm", Toast.LENGTH_SHORT).show();
                } else if (edt_decryption_key.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please Enter Key", Toast.LENGTH_SHORT).show();
                } else {
                    if (decryptedAlgorithm.equals("Caesar Cipher Algorithm")) {
                        int dKey = Integer.parseInt(edt_decryption_key.getText().toString());
                        while (dKey > 26) {
                            dKey = dKey / 26;
                        }
                        final_decrypted_text.setText("Decrypt Message : \n" + caesarCipherDecryption(dKey, edt_decyption_message.getText().toString()));
                    } else if (decryptedAlgorithm.equals("Rail Fence Cipher Algorithm")) {
                        final_decrypted_text.setText("Decrypt Message : \n" + railFenceDecryption(Integer.parseInt(edt_decryption_key.getText().toString()), edt_decyption_message.getText().toString()));
                    } else if (decryptedAlgorithm.equals("PlayFair Cipher Algorithm")) {
                        final_decrypted_text.setText("Decrypt Message : \n" + playFairCypherDecryption(edt_decryption_key.getText().toString(), edt_decyption_message.getText().toString()));
                    } else if (decryptedAlgorithm.equals("Vigenere Cipher Algorithm")) {
                        final_decrypted_text.setText("Decrypt Message : \n" + vigenereCypherDecryption(edt_decryption_key.getText().toString(), edt_decyption_message.getText().toString()));
                    }
                }

                }catch (Exception e)
                {
                    Toast.makeText(MainActivity.this, e.toString()+"", Toast.LENGTH_SHORT).show();
                }
            }

        });

        checkAndRequestPermissions();
    }

    //Caesar Cipher

    private String caesarCipherEncryption(int shift, String plaintext) {
        String ciphertext = "";
        char alphabet;
        for (int i = 0; i < plaintext.length(); i++) {
            // Shift one character at a time
            alphabet = plaintext.charAt(i);

            // if alphabet lies between a and z
            if (alphabet >= 'a' && alphabet <= 'z') {
                // shift alphabet
                alphabet = (char) (alphabet + shift);
                // if shift alphabet greater than 'z'
                if (alphabet > 'z') {
                    // reshift to starting position
                    alphabet = (char) (alphabet + 'a' - 'z' - 1);
                }
                ciphertext = ciphertext + alphabet;
            }

            // if alphabet lies between 'A'and 'Z'
            else if (alphabet >= 'A' && alphabet <= 'Z') {
                // shift alphabet
                alphabet = (char) (alphabet + shift);

                // if shift alphabet greater than 'Z'
                if (alphabet > 'Z') {
                    //reshift to starting position
                    alphabet = (char) (alphabet + 'A' - 'Z' - 1);
                }
                ciphertext = ciphertext + alphabet;
            } else {
                ciphertext = ciphertext + alphabet;
            }

        }
        System.out.println(" ciphertext : " + ciphertext);
        return ciphertext;
    }

    private String caesarCipherDecryption(int shift, String ciphertext) {
        String decryptMessage = "";
        for (int i = 0; i < ciphertext.length(); i++) {
            // Shift one character at a time
            char alphabet = ciphertext.charAt(i);
            // if alphabet lies between a and z
            if (alphabet >= 'a' && alphabet <= 'z') {
                // shift alphabet
                alphabet = (char) (alphabet - shift);

                // shift alphabet lesser than 'a'
                if (alphabet < 'a') {
                    //reshift to starting position
                    alphabet = (char) (alphabet - 'a' + 'z' + 1);
                }
                decryptMessage = decryptMessage + alphabet;
            }
            // if alphabet lies between A and Z
            else if (alphabet >= 'A' && alphabet <= 'Z') {
                // shift alphabet
                alphabet = (char) (alphabet - shift);

                //shift alphabet lesser than 'A'
                if (alphabet < 'A') {
                    // reshift to starting position
                    alphabet = (char) (alphabet - 'A' + 'Z' + 1);
                }
                decryptMessage = decryptMessage + alphabet;
            } else {
                decryptMessage = decryptMessage + alphabet;
            }
        }
        return decryptMessage;
    }

    //RailFence

    public String railFenceEncryption(int depth,String plainText)throws Exception
    {
        int r=depth,len=plainText.length();
        int c=len/depth;
        char mat[][]=new char[r][c];
        int k=0;

        String cipherText="";

        for(int i=0;i< c;i++)
        {
            for(int j=0;j< r;j++)
            {
                if(k!=len)
                    mat[j][i]=plainText.charAt(k++);
                else
                    mat[j][i]='X';
            }
        }
        for(int i=0;i< r;i++)
        {
            for(int j=0;j< c;j++)
            {
                cipherText+=mat[i][j];
            }
        }
        Log.d("cipherTextRailfence",cipherText+" ");
        return cipherText;
    }

    public String railFenceDecryption(int depth, String cipherText) {
        int r = depth, len = cipherText.length();
        int c = len / depth;
        char mat[][] = new char[r][c];
        int k = 0;

        String plainText = "";

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                mat[i][j] = cipherText.charAt(k++);
            }
        }
        for (int i = 0; i < c; i++) {
            for (int j = 0; j < r; j++) {
                plainText += mat[j][i];
            }
        }

        return plainText;
    }

    //Play Fair

    public String playFairCypherEncryption(final String key, String plainText) {
        insertKey(key);
        String cipherText = "";
        plainText = plainText.replaceAll("j", "i");
        plainText = plainText.replaceAll(" ", "");
        plainText = plainText.toUpperCase();
        int len = plainText.length();
        // System.out.println(plainText.substring(1,2+1));
        if (len / 2 != 0) {
            plainText += "X";
            ++len;
        }

        for (int i = 0; i < len - 1; i = i + 2) {
            cipherText += encryptChar(plainText.substring(i, i + 2));
            cipherText += " ";
        }
        return cipherText;
    }

    Basic b = new Basic();
    char keyMatrix[][] = new char[5][5];

    String encryptChar(String plain) {
        plain = plain.toUpperCase();
        char a = plain.charAt(0), b = plain.charAt(1);
        String cipherChar = "";
        int r1, c1, r2, c2;
        r1 = rowPos(a);
        c1 = columnPos(a);
        r2 = rowPos(b);
        c2 = columnPos(b);

        if (c1 == c2) {
            ++r1;
            ++r2;
            if (r1 > 4)
                r1 = 0;

            if (r2 > 4)
                r2 = 0;
            cipherChar += keyMatrix[r1][c2];
            cipherChar += keyMatrix[r2][c1];
        } else if (r1 == r2) {
            ++c1;
            ++c2;
            if (c1 > 4)
                c1 = 0;

            if (c2 > 4)
                c2 = 0;
            cipherChar += keyMatrix[r1][c1];
            cipherChar += keyMatrix[r2][c2];

        } else {
            cipherChar += keyMatrix[r1][c2];
            cipherChar += keyMatrix[r2][c1];
        }
        return cipherChar;
    }

    class Basic {
        String allChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        boolean indexOfChar(char c) {
            for (int i = 0; i < allChar.length(); i++) {
                if (allChar.charAt(i) == c)
                    return true;
            }
            return false;
        }
    }

    boolean repeat(char c) {
        if (!b.indexOfChar(c)) {
            return true;
        }
        for (int i = 0; i < keyMatrix.length; i++) {
            for (int j = 0; j < keyMatrix[i].length; j++) {
                if (keyMatrix[i][j] == c || c == 'J')
                    return true;
            }
        }
        return false;
    }

    void insertKey(String key) {
        key = key.toUpperCase();
        key = key.replaceAll("J", "I");
        key = key.replaceAll(" ", "");
        int a = 0, b = 0;

        for (int k = 0; k < key.length(); k++) {
            if (!repeat(key.charAt(k))) {
                keyMatrix[a][b++] = key.charAt(k);
                if (b > 4) {
                    b = 0;
                    a++;
                }
            }
        }

        char p = 'A';

        while (a < 5) {
            while (b < 5) {
                if (!repeat(p)) {
                    keyMatrix[a][b++] = p;

                }
                p++;
            }
            b = 0;
            a++;
        }
        System.out.print("-------------------------Key Matrix-------------------");
        for (int i = 0; i < 5; i++) {
            System.out.println();
            for (int j = 0; j < 5; j++) {
                System.out.print("\t" + keyMatrix[i][j]);
            }
        }
        System.out.println("\n---------------------------------------------------------");

    }

    int rowPos(char c) {
        for (int i = 0; i < keyMatrix.length; i++) {
            for (int j = 0; j < keyMatrix[i].length; j++) {
                if (keyMatrix[i][j] == c)
                    return i;
            }
        }
        return -1;
    }

    int columnPos(char c) {
        for (int i = 0; i < keyMatrix.length; i++) {
            for (int j = 0; j < keyMatrix[i].length; j++) {
                if (keyMatrix[i][j] == c)
                    return j;
            }
        }
        return -1;
    }

    String decrypt(String key, String encpt) {
        char[] encpt_arr = encpt.toCharArray();
        char[] key_arr = key.toCharArray();
        char[] alpha = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L',
                'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        char[][] table = new char[5][5];
        int ctr = -1;
        for (int i = 0; i < key_arr.length; i++)
            for (int j = 0; j < 25; j++)
                if (key_arr[i] == alpha[j]) {
                    ctr++;
                    int round = ctr / 5;
                    table[round][ctr % 5] = alpha[j];
                    alpha[j] = '0';
                    break;
                }
        for (int i = 0; i < alpha.length; i++) {
            if (alpha[i] != '0') {
                ctr++;
                int round = ctr / 5;
                table[round][ctr % 5] = alpha[i];
            }
        }
        System.out.println("\nThe Reference Table is:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) System.out.print(table[i][j] + " ");
            System.out.println();
        }
        char[] any = new char[encpt_arr.length];
        int any_ctr = 0;
        for (int i = 0; i < encpt_arr.length; i = i + 2) {
            int row1 = 0, row2 = 0, col1 = 0, col2 = 0;
            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < 5; k++) {
                    if (encpt_arr[i] == table[j][k]) {
                        row1 = j;
                        col1 = k;
                        break;
                    }
                }
            }
            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < 5; k++) {
                    if (encpt_arr[i + 1] == table[j][k]) {
                        row2 = j;
                        col2 = k;
                        break;
                    }
                }
            }
            if (row1 == row2) {
                col1 = (col1 - 1 + 5) % 5;
                col2 = (col2 - 1 + 5) % 5;
                any[any_ctr++] = table[row1][col1];
                any[any_ctr++] = table[row2][col2];
            } else if (col1 == col2) {
                row1 = (row1 - 1 + 5) % 5;
                row2 = (row2 - 1 + 5) % 5;
                any[any_ctr++] = table[row1][col1];
                any[any_ctr++] = table[row2][col2];
            } else if (row1 != row2 && col1 != col2) {
                int row = 0, col = 0;
                row = row1;
                col = col2;
                any[any_ctr++] = table[row][col];
                row = row2;
                col = col1;
                any[any_ctr++] = table[row][col];
            } else {
            }
        }
        System.out.print("\nThe Intermediate Text is: ");
        for (int i = 0; i < any_ctr; i++) System.out.print(any[i]);
        char[] decpt_arr = new char[100];
        int decpt_arr_ctr = 0;
        for (int i = 0; i < any_ctr; i++) {
            if (i == 0) {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i == 1 && any[i - 1] == any[i + 1] && any[i] == 'X') {
                continue;
            }
            if (i == 1 && any[i - 1] != any[i + 1] && any[i] != 'X') {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i == 2 && any[i - 1] == any[i + 1] && any[i] == 'X') {
                continue;
            }
            if (i == 2 && any[i - 1] != any[i + 1] && any[i] != 'X') {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i != any_ctr - 2 && i != any_ctr - 1 && any[i - 1] == any[i + 1] && any[i] == 'X') {
                continue;
            }
            if (i != any_ctr - 2 && i != any_ctr - 1 && any[i - 1] == any[i + 1] && any[i] != 'X') {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i == any_ctr - 2 && any[i - 1] == any[i + 1] && any[i] == 'X') {
                continue;
            }
            if (i == any_ctr - 2 && any[i - 1] == any[i + 1] && any[i] != 'X') {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i == any_ctr - 1 && i % 2 != 0 && any[i] == 'X') {
                continue;
            }
            if (i == any_ctr - 1 && any[i] != 'X') {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
            if (i == any_ctr - 1 && i % 2 == 0 && any[i] == 'X') {
                continue;
            }
            if (i >= 0) {
                decpt_arr[decpt_arr_ctr++] = any[i];
                continue;
            }
        }
        System.out.print("\n\nThe Decrypted Text is: ");
        String s = null;
        for (int i = 0; i < decpt_arr_ctr; i++) {
            s= s+decpt_arr[i];
            System.out.print(decpt_arr[i]);
        };
        return  s;
    }

    public String playFairCypherDecryption(final String key, String cipher) {

        insertKey(key);
        cipher = cipher.toUpperCase();
        char a = cipher.charAt(0), b = cipher.charAt(1);
        String plainChar = "";
        int r1, c1, r2, c2;
        r1 = rowPos(a);
        c1 = columnPos(a);
        r2 = rowPos(b);
        c2 = columnPos(b);

        if (c1 == c2) {
            --r1;
            --r2;
            if (r1 < 0)
                r1 = 4;

            if (r2 < 0)
                r2 = 4;

            Log.d("Matrix:" + keyMatrix[r1][c2] + "\n===\n" + keyMatrix[r2][c1], "");
            plainChar += keyMatrix[r1][c2];
            plainChar += keyMatrix[r2][c1];
        } else if (r1 == r2) {
            --c1;
            --c2;
            if (c1 < 0)
                c1 = 4;

            if (c2 < 0)
                c2 = 4;

            Log.d("Matrix1:" + keyMatrix[r1][c2] + "\n===\n" + keyMatrix[r2][c1], "");
            plainChar += keyMatrix[r1][c1];
            plainChar += keyMatrix[r2][c2];

        } else {

            Log.d("Matrix3:" + keyMatrix[r1][c2] + "\n===\n" + keyMatrix[r2][c1], "");
            plainChar += keyMatrix[r1][c2];
            plainChar += keyMatrix[r2][c1];
        }
        return plainChar;
    }

    //Vigenere

    public static String vigenereCypherEncryption(final String key, String text) {
        String res = "";
        text = text.toUpperCase();
        for (int i = 0, j = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < 'A' || c > 'Z')
                continue;
            res += (char) ((c + key.charAt(j) - 2 * 'A') % 26 + 'A');
            j = ++j % key.length();
        }
        return res;
    }

    public static String vigenereCypherDecryption(final String key, String text) {
        String res = "";
        text = text.toUpperCase();
        for (int i = 0, j = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c < 'A' || c > 'Z')
                continue;
            res += (char) ((c - key.charAt(j) + 26) % 26 + 'A');
            j = ++j % key.length();
        }
        return res;
    }


    private static boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public void EnableRuntimePermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                Manifest.permission.READ_CONTACTS)) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.READ_CONTACTS}, RequestPermissionCode);

//            Toast.makeText(MainActivity.this,"CONTACTS permission allows us to Access CONTACTS app", Toast.LENGTH_LONG).show();

        } else {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.READ_CONTACTS}, RequestPermissionCode);
            intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            startActivityForResult(intent, 7);
        }
    }

    @Override
    public void onRequestPermissionsResult(int RC, String per[], int[] PResult) {

        switch (RC) {

            case RequestPermissionCode:

                if (PResult.length > 0 && PResult[0] == PackageManager.PERMISSION_GRANTED) {

//                    Toast.makeText(MainActivity2.this,"Permission Granted, Now your application can access CONTACTS.", Toast.LENGTH_LONG).show();

                    // EnableRuntimePermission();
                } else {

                    EnableRuntimePermission();
//                    Toast.makeText(MainActivity2.this,"Permission Canceled, Now your application cannot access CONTACTS.", Toast.LENGTH_LONG).show();

                }

                break;
        }
    }

    @Override
    public void onActivityResult(int RequestCode, int ResultCode, Intent ResultIntent) {

        super.onActivityResult(RequestCode, ResultCode, ResultIntent);

        switch (RequestCode) {

            case (7):
                if (ResultCode == Activity.RESULT_OK) {

                    Uri uri;
                    Cursor cursor1, cursor2;
                    String TempNameHolder, TempNumberHolder, TempContactID, IDresult = "";
                    int IDresultHolder;

                    uri = ResultIntent.getData();

                    cursor1 = getContentResolver().query(uri, null, null, null, null);

                    if (cursor1.moveToFirst()) {

                        TempNameHolder = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                        TempContactID = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts._ID));

                        IDresult = cursor1.getString(cursor1.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                        IDresultHolder = Integer.valueOf(IDresult);

                        if (IDresultHolder == 1) {

                            cursor2 = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + TempContactID, null, null);

                            while (cursor2.moveToNext()) {

                                TempNumberHolder = cursor2.getString(cursor2.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

//                                edtincome.setText(TempNameHolder);

                                edt_mobile.setText(TempNumberHolder);

                            }
                        }

                    }
                }
                break;
        }
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                final String message = intent.getStringExtra("message");
                final String sender = intent.getStringExtra("Sender");
//                otpOnlyTextView.setText(message.replaceAll("\\D+", ""));
//                fullmessageTextView.setText(sender + " : " + message);
                edt_decyption_message.setText(message);
                Toast.makeText(getBaseContext(), message, Toast.LENGTH_LONG).show();
                Log.e("OTP MESSSGE", message);
            }
        }
    };

    private boolean checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            int receiveSMS = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS);
            int readSMS = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS);
            List<String> listPermissionsNeeded = new ArrayList<>();
            if (receiveSMS != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
            }
            if (readSMS != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(android.Manifest.permission.READ_SMS);
            }
            if (!listPermissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this,
                        listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
                return false;
            }
            return true;
        }
        return true;

    }

    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }

    @Override
    public void onBackPressed() {

        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);

        super.onBackPressed();
    }

}
